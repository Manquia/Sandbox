void InitInteraction();
